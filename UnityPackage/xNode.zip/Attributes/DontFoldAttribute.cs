﻿using System;

public class DontFoldAttribute : Attribute { }
